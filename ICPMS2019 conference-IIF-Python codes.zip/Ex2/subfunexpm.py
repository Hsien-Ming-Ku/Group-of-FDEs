# -*- coding: utf-8 -*-
"""
Created on 28 April,2019
Example 2 in the conference article: 
Yong-Liang Zhao, Pei-Yong Zhu, Xian-Ming Gu, Xi-Le Zhao and Huan-Yan Jian,
   An implicit integration factor method for a kind of spatial fractional 
     diffusion equations, The Second International Conference on Physics, 
     Mathematics and Statistics, 7 pages

@Code writers:
1. Y.-L. Zhao 
   Institution: School of Mathematical Sciences, 
      University of Electronic Science and Technology of China,
        Chengdu, Sichuan 611731, P.R. China
   E-mail: ylzhaofde@sina.com
2. X.-M. Gu 
   Institution: School of Economic Mathematics/Institute of Mathematics,
     Southwestern University of Finance and Economics,
       Chengdu, Sichuan 611130, P.R. China
   E-mail: guxianming@live.cn, x.m.gu@rug.nl

@Copyright: 
School of Mathematical Sciences,
University of Electronic Science and Technology of China (UESTC), 
Chengdu, 611731, P.R. China  
Y.-L. Zhao
"""

# All subfuncs. needed in mainprogram.py
import numpy as np
from scipy.special import gamma
from warnings import warn

# !. Subfunc to calculate the coeffs. d_{\pm}(x,t) and u0(x)
def coeffs(x):
    n = x.shape[0]
    d1 = np.zeros((n,))
    d2 = np.ones((n,))
    for i in range(n):
        if x[i] < 0:
            d1[i] = 1.5*np.exp(-x[i])
        else:
            d1[i] = 1
        #endif
    #endfor
    u0 = 4*np.exp(10*x)/(np.exp(10*x) + 1)**2
    return d1, d2, u0
# enddef

# 2. Subfun to calculate the weights
def weights(alpha,N):
    temp = np.arange(N)
    a = (temp + 1)**(1 - alpha) - temp**(1 - alpha)
    g = (a - np.append([0],a[0:-1]))/gamma(2 - alpha)
    a = a/gamma(2 - alpha)
    return a, g
# enddef

# 3. Subfun of fixed point iterative method
def fixediter(y0, f, constant_part, tau, maxit, tol):
# Fixed point iterative method
# Input: 
#       y0 -> Initial guess
#       constant_part -> exp(-A*tau)[U^{n} + tau/2*F(U^{n})]
#       tau -> The temporal step size
#       maxit -> Maximum iterative step
#       tol -> The tolerance
    old_y = y0.copy()
    relres = 1.0
    r0 = np.linalg.norm(y0)    
    
    for iter in range(maxit):
        if relres <= tol:
            break
            #return old_y, iter + 1
        #endif
        new_y = constant_part + tau/2*f(old_y)
        relres = np.linalg.norm(new_y - old_y)/r0
        old_y = new_y.copy()
    #endfor
    if iter >= maxit - 1:
       warn('The maxit is reached!',UserWarning)
    #endif
    return old_y, iter + 1                
 # enddef   