# -*- coding: utf-8 -*-
"""
Created on 28 April,2019
Example 1 in the conference article: 
Yong-Liang Zhao, Pei-Yong Zhu, Xian-Ming Gu, Xi-Le Zhao and Huan-Yan Jian,
   An implicit integration factor method for a kind of spatial fractional 
     diffusion equations, The Second International Conference on Physics, 
     Mathematics and Statistics, 7 pages

@Code writers: 
1. Y.-L. Zhao 
   Institution: School of Mathematical Sciences, 
      University of Electronic Science and Technology of China,
        Chengdu, Sichuan 611731, P.R. China
   E-mail: ylzhaofde@sina.com
2. X.-M. Gu 
   Institution: School of Economic Mathematics/Institute of Mathematics,
     Southwestern University of Finance and Economics,
       Chengdu, Sichuan 611130, P.R. China
   E-mail: guxianming@live.cn, x.m.gu@rug.nl
   
@Copyright: 
School of Mathematical Sciences,
University of Electronic Science and Technology of China (UESTC), 
Chengdu, 611731, P.R. China  
Y.-L. Zhao
"""
## Main func ##
## Import modules ##
import numpy as np
from scipy.linalg import toeplitz, expm
import gc
import subfunexpm as subfun # Import the subfunexpm.py

gc.disable()
## Input ##
alpha = 0.6                        # space frac order (0.5~1)
x_L = 0.0; x_R = 1.0               # Space interval
T = 1.0                            # Time interval
N = 2**6                           # Space grid number
M = N                              # Time grid number
f = lambda v: 100*v*(v - 0.5)*(1 - v)

## Initial set ##
u = np.zeros((N + 1, M + 1))       # Numerical solution
h = (x_R - x_L)/N
tau = T/M
eta = 1/h**(2*alpha)
d1,d2,u[:,0] = subfun.coeffs(alpha,x_L + np.arange(N + 1)*h)
a,g = subfun.weights(alpha,N)
outiter = np.zeros((M,1))
maxit = 200; tol = 1.0e-12         # Maxit and tol for fixed-point iteration 

## The matries ##
tild_G = toeplitz(g[0:N - 1],np.append(g[0],np.zeros((N - 2,1))))
# Left
GL1 = np.hstack((-a[0:N - 1].reshape(-1,1),tild_G))
GR1 = np.vstack((g[1:N],tild_G.T))
# Right
GL2 = np.hstack((tild_G.T,-a[N - 2::-1].reshape(-1,1)))
GR2 = np.vstack((tild_G,g[N - 1:0:-1]))
# Diagonal maxtrices
D1 = np.diag(d1[0:N]); D2 = np.diag(d2[1:N + 1])
# The matrix from spatial discretization
A = eta*(GL1@D1@GR1 + GL2@D2@GR2)

## IIF2 scheme ##
expA = expm(-tau*A)
for j in range(M):
    constant_part = expA@(u[1:N,j] + tau/2*f(u[1:N,j]))
    u[1:N,j + 1], outiter[j] = \
       subfun.fixediter(u[1:N,j],f,constant_part,tau,maxit,tol)
#endfor
gc.enable()
del a, g, d1, d2, eta, constant_part, j
gc.collect()

## Output ##
print("IIF2 (Python version) -- Ex1\n")
print("alpha, domain = %.2f, \t[%.1f, %.1f] & [0.0, %.1f]\n" %(alpha,x_L,x_R,T))
print("(N, M): (%d, %d)\n" %(N, M))
print("Average Iter: %.1f\n" %(outiter.mean()))
