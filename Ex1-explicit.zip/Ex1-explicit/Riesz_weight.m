function Riesz_g = Riesz_weight(beta,n)
% Toeplitz matrix A (Riesz fractional derivative of order beta (1 < beta < 2))
% The coeff w^(beta)
Riesz_g = zeros(n - 1,1);
Riesz_g(1) = gamma(beta + 1)/(gamma(beta/2 + 1)^2);    % w(0)
for m = 2:n - 1
    k = m - 1;
    Riesz_g(m) = (1 - (beta + 1)/(beta/2 + k))*Riesz_g(k);
end
% Toeplitz matrix A (Symetric Positive Matrix)
% A = toeplitz(w,w);

% @Code writers: 
% 1. Y.-L. Zhao 
%    Institution: School of Mathematical Sciences, 
%       University of Electronic Science and Technology of China,
%         Chengdu, Sichuan 611731, P.R. China
%    E-mail: ylzhaofde@sina.com
% 2. X.-M. Gu 
%    Institution: School of Economic Mathematics/Institute of Mathematics,
%      Southwestern University of Finance and Economics,
%        Chengdu, Sichuan 611130, P.R. China
%    E-mail: guxianming@live.cn, x.m.gu@rug.nl
%    
% @Copyright: 
% School of Mathematical Sciences,
% University of Electronic Science and Technology of China (UESTC), 
% Chengdu, 611731, P.R. China  
% Y.-L. Zhao