function u = u_fun(alpha,x,t)
% Exact solution u(x,t)
u = x.^2.*(1 - x).^2*(1 + t).^(alpha);