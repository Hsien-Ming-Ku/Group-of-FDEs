% 
% Created on 31 May,2019
% Example 1 (explicit scheme Eq. (2.11)) in the article: 
%    Y.-Y. Huang and X.-M. Gu,
%       Fast implicit difference schemes for solving the nonlinear
%            fractional diffusion equations
% 
% @Code writers: 
% 1. Y.-L. Zhao 
%    Institution: School of Mathematical Sciences, 
%       University of Electronic Science and Technology of China,
%         Chengdu, Sichuan 611731, P.R. China
%    E-mail: ylzhaofde@sina.com
% 2. X.-M. Gu 
%    Institution: School of Economic Mathematics/Institute of Mathematics,
%      Southwestern University of Finance and Economics,
%        Chengdu, Sichuan 611130, P.R. China
%    E-mail: guxianming@live.cn, x.m.gu@rug.nl
%    
% @Copyright: 
% School of Mathematical Sciences,
% University of Electronic Science and Technology of China (UESTC), 
% Chengdu, 611731, P.R. China  
% Y.-L. Zhao

clear;close all;clc;


alpha = 1.5;      % The order of Riesz fractional (1 < alpha < 2)
x_L = 0; x_R = 1; % The space domain
T = 1;            % The final moment
N = 64;           % Space grid number: N = [4,8,16,32,64], M = N^2
M =N^2;          % Time grid number: N = 2^10, M = 2.^(3:7)
au = @(u) u.^2;   % The nonlinear term a(u)


h = (x_R - x_L)/N;
tau = T/M;
coeff = tau/h^alpha;
x = x_L + (0:N).'*h;
t = (0:M)*tau;
u = zeros(N + 1,M + 1);
f = u;


% Exact solution u(x,t)
du = u_fun(alpha,x,t);
% Source term f(x,t)
for j = 1:M + 1
    f(:,j) = f_fun(alpha,au(du(:,j)),x,t(j));
end

% Initial value
u(:,1) = u_fun(alpha,x,0);
% Boundary value
% % u(1,:) = 0; u(N + 1,:) = 0;
tic;

I_x = speye(N - 1);
Riesz_g = Riesz_weight(alpha,N);
G_alpha = toeplitz(Riesz_g);


for j = 1:M
    coeffmat = I_x + coeff*diag(au(u(2:N,j)))*G_alpha;
    rv = u(2:N,j) + tau*f(2:N,j + 1);
    u(2:N,j + 1) = coeffmat\rv;
end
interval = toc;

% Absolute error
err = abs(u - du);
% L-2 norm error
for j = 1:M + 1
    sq_err = norm(err(:,j));
end   
msq_err = sqrt(h)*max(sq_err);
clearvars sq_err j;
% L-inf norm error 
mmax_err = max(max(err));
clear coeff coeffmat Riesz_g G_alpha I_x rv h tau;


fprintf('Strong nonlinear Ex1\n')
fprintf('alpha, domain: %.2f,\t[%.1f,%.1f] & [0.0,%.1f]\n',alpha,x_L,x_R,T);
fprintf('(N,M): (%d,%d)\n',N,M);
fprintf('mmax_error\t msq_error: \n%.4e\t%.4e\n',mmax_err,msq_err);
fprintf('CPU: %.3f\n',interval);
