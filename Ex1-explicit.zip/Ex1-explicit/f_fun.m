function f = f_fun(alpha,au,x,t)
% Source term f(x,t)
f0 = alpha*(1 + t)^(alpha - 1)*x.^2.*(1 - x).^2;
f1 = (1 + t)^(alpha)*(1 - x).^(2 - alpha);
f2 = 12*x.^2 - 6*alpha*x + alpha*(alpha - 1);
f3 = (1 + t)^(alpha)*x.^(2 - alpha);
f4 = 12*(1 - x).^2 + alpha*(6*x - 7) + alpha^2;

f = f0 + au/gamma(5 - alpha).*(f1.*f2 + f3.*f4)*sec(pi*alpha/2);